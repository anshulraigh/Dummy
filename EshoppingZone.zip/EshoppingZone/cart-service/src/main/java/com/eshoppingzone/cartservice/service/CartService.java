package com.eshoppingzone.cartservice.service;

import com.eshoppingzone.cartservice.client.OrderClient;
import com.eshoppingzone.cartservice.client.ProductClient;
import com.eshoppingzone.cartservice.config.UserContext;
import com.eshoppingzone.cartservice.dto.OrderDTO;
import com.eshoppingzone.cartservice.dto.OrderItemDTO;
import com.eshoppingzone.cartservice.dto.ProductDTO;
import com.eshoppingzone.cartservice.exception.*;
import com.eshoppingzone.cartservice.model.CartItem;
import com.eshoppingzone.cartservice.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.ArrayList;

@Service
public class CartService {

    @Autowired private CartRepository cartRepository;
    @Autowired private ProductClient productClient;
    @Autowired private OrderClient orderClient;

    public List<CartItem> getCartItemsByUser() {
        Long userId = UserContext.getUserId();
        return cartRepository.findByUserId(userId);
    }

    public CartItem addToCart(CartItem item) {
        Long userId = UserContext.getUserId();
        item.setUserId(userId);

        ProductDTO product = productClient.getProductById(item.getProductId());
        if (product == null) {
            throw new ProductNotFoundException("Product not found with id: " + item.getProductId());
        }

        if (product.getQuantity() < item.getQuantity()) {
            throw new InsufficientStockException("Insufficient stock for product: " + product.getName());
        }

        CartItem existingItem = cartRepository.findByUserIdAndProductId(userId, item.getProductId());
        if (existingItem != null) {
            existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
            return cartRepository.save(existingItem);
        }

        return cartRepository.save(item);
    }

    public void removeFromCart(Long itemId) {
        Long userId = UserContext.getUserId();
        CartItem item = cartRepository.findById(itemId)
                .orElseThrow(() -> new CartItemNotFoundException("Cart item not found with id: " + itemId));

        if (!item.getUserId().equals(userId)) {
            throw new AccessDeniedException("You cannot remove items from another user's cart.");
        }

        cartRepository.deleteById(itemId);
    }

    public void clearCart() {
        Long userId = UserContext.getUserId();
        cartRepository.deleteByUserId(userId);
    }

    public String placeOrder() {
        Long userId = UserContext.getUserId();
        List<CartItem> items = cartRepository.findByUserId(userId);

        if (items.isEmpty()) {
            return "Cart is empty. Cannot place order.";
        }

        List<OrderItemDTO> orderItems = new ArrayList<>();

        for (CartItem item : items) {
            ProductDTO product = productClient.getProductById(item.getProductId());
            if (product == null || product.getQuantity() < item.getQuantity()) {
                throw new InsufficientStockException("Insufficient stock for product: " + (product != null ? product.getName() : "Unknown"));
            }

            productClient.reduceProductQuantity(item.getProductId(), item.getQuantity());

            orderItems.add(new OrderItemDTO(
                    item.getProductId(),
                    product.getName(),
                    product.getPrice(),
                    item.getQuantity()
            ));
        }

        OrderDTO order = new OrderDTO(userId, orderItems);
        orderClient.placeOrder(order);

        cartRepository.deleteByUserId(userId);

        return "Order placed successfully!";
    }
}
