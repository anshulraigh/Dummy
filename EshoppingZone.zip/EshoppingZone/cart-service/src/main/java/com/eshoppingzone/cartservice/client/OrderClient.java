package com.eshoppingzone.cartservice.client;

import com.eshoppingzone.cartservice.dto.OrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "ORDER-SERVICE")
public interface OrderClient {
    @PostMapping("/orders")
    void placeOrder(OrderDTO order);
}
