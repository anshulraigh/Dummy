package com.eshoppingzone.cartservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class OrderDTO {
    private Long userId;
    private List<OrderItemDTO> items;
}
