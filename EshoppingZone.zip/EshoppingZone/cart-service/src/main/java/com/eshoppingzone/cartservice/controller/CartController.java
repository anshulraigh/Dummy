package com.eshoppingzone.cartservice.controller;

import com.eshoppingzone.cartservice.model.CartItem;
import com.eshoppingzone.cartservice.service.CartService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@Tag(name = "Cart Controller", description = "Operations related to managing the shopping cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping
    @Operation(summary = "Get Cart Items", description = "Retrieve all cart items for the current logged-in user")
    public List<CartItem> getCartItems() {
        return cartService.getCartItemsByUser();
    }

    @PostMapping
    @Operation(summary = "Add Item to Cart", description = "Add a new item to the cart for the current user")
    public CartItem addToCart(
            @Parameter(description = "Cart item object containing product ID and quantity", required = true)
            @RequestBody CartItem item) {
        return cartService.addToCart(item);
    }

    @DeleteMapping("/{itemId}")
    @Operation(summary = "Remove Item from Cart", description = "Remove a specific item from the current user's cart by item ID")
    public void removeFromCart(
            @Parameter(description = "ID of the cart item to be removed", required = true)
            @PathVariable Long itemId) {
        cartService.removeFromCart(itemId);
    }

    @DeleteMapping("/clear")
    @Operation(summary = "Clear Cart", description = "Remove all items from the current user's cart")
    public void clearCart() {
        cartService.clearCart();
    }

    @PostMapping("/order")
    @Operation(summary = "Place Order", description = "Place an order for all items currently in the user's cart")
    public String placeOrder() {
        return cartService.placeOrder();
    }
}
