package com.eshoppingzone.cartservice.client;

import com.eshoppingzone.cartservice.dto.ProductDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "PRODUCT-SERVICE")
public interface ProductClient {

    @GetMapping("/products/{id}")
    ProductDTO getProductById(@PathVariable Long id);

    @PutMapping("/products/{id}/reduce-stock")
    boolean reduceProductQuantity(@PathVariable Long id, @RequestParam("quantity") int quantity);
}
