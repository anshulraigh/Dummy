package com.eshoppingzone.messaging_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
