package com.eshoppingzone.userservice.model;

public enum Role {
    USER,
    ADMIN
}