package com.eshoppingzone.authservice.enums;

public enum Role {
    ADMIN,
    USER
}
