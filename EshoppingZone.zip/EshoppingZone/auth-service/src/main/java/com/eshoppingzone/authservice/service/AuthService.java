package com.eshoppingzone.authservice.service;

import com.eshoppingzone.authservice.entity.UserInfo;
import com.eshoppingzone.authservice.exception.UserAlreadyExistsException;
import com.eshoppingzone.authservice.exception.UserNotFoundException;
import com.eshoppingzone.authservice.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserInfoRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    public String addUser(UserInfo userInfo) {
        if (repository.findByEmail(userInfo.getEmail()).isPresent()) {
            throw new UserAlreadyExistsException("User with email already exists");
        }

        userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
        userInfo.setRole(userInfo.getRole() != null ? userInfo.getRole() : "user");
        repository.save(userInfo);
        return "User Added";
    }

    public void validateToken(String token) {
        jwtService.validateToken(token);
    }

    public String generateToken(String email) {
        UserInfo user = repository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
        return jwtService.generateToken(user);
    }
}
