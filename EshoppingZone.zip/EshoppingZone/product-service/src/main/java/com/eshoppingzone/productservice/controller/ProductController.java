package com.eshoppingzone.productservice.controller;

import com.eshoppingzone.productservice.entity.Product;
import com.eshoppingzone.productservice.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/products")
@Tag(name = "Product API", description = "Endpoints for managing products")
@SecurityRequirement(name = "JWT_AUTH")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    @Operation(summary = "Get all products")
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a product by ID")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/category/{categoryId}")
    @Operation(summary = "Get products by category ID")
    public List<Product> getProductsByCategory(@PathVariable Long categoryId) {
        return productService.getProductsByCategory(categoryId);
    }

    @PostMapping
    @Operation(summary = "Add a new product")
    public ResponseEntity<?> addProduct(@RequestBody Product product) {
        try {
            return ResponseEntity.ok(productService.addProduct(product));
        } catch (Exception e) {
            log.error("Error adding product", e);
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing product")
    public ResponseEntity<?> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        try {
            return ResponseEntity.ok(productService.updateProduct(id, product));
        } catch (Exception e) {
            log.error("Error updating product with id " + id, e);
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a product by ID")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        return productService.deleteProduct(id) ?
                ResponseEntity.noContent().build() :
                ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}/reduce-stock")
    @Operation(summary = "Reduce stock of a product")
    public ResponseEntity<?> reduceStock(@PathVariable Long id, @RequestParam int quantity) {
        try {
            boolean success = productService.reduceProductQuantity(id, quantity);
            return ResponseEntity.ok(success);
        } catch (Exception e) {
            log.error("Error reducing stock", e);
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}/restore-stock")
    @Operation(summary = "Restore stock of a product")
    public ResponseEntity<?> restoreStock(@PathVariable Long id, @RequestParam int quantity) {
        try {
            productService.restoreProductQuantity(id, quantity);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            log.error("Error restoring stock", e);
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/circuit-breaker/state")
    @Operation(summary = "Check the circuit breaker state")
    public String getCircuitBreakerState() {
        return productService.getCircuitBreakerState();
    }
}