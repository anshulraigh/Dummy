package com.eshoppingzone.productservice.exception;

public class CategoryUnavailableException extends RuntimeException {
    public CategoryUnavailableException(String message) {
        super(message);
    }
}
