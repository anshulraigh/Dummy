package com.eshoppingzone.productservice.service;

import com.eshoppingzone.productservice.client.CategoryClient;
import com.eshoppingzone.productservice.config.UserContext;
import com.eshoppingzone.productservice.dto.Category;
import com.eshoppingzone.productservice.entity.Product;
import com.eshoppingzone.productservice.exception.AccessDeniedException;
import com.eshoppingzone.productservice.exception.ProductNotFoundException;
import com.eshoppingzone.productservice.repository.ProductRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private static final String CATEGORY_CB = "categoryServiceCB";

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryClient categoryClient;

    @Autowired
    private CircuitBreakerRegistry circuitBreakerRegistry;

    public List<Product> getAllProducts() {
        List<Product> products = productRepository.findAll();
        products.forEach(this::attachCategoryName);
        return products;
    }

    public Optional<Product> getProductById(Long id) {
        Optional<Product> product = productRepository.findById(id);
        product.ifPresent(this::attachCategoryName);
        return product;
    }

    public List<Product> getProductsByCategory(Long categoryId) {
        List<Product> products = productRepository.findByCategoryId(categoryId);
        products.forEach(this::attachCategoryName);
        return products;
    }

    public Product addProduct(Product product) {
        ensureAdminRole();

        if (product.getQuantity() < 0) {
            throw new IllegalArgumentException("Product quantity cannot be negative.");
        }

        Category category = getCategoryWithCircuitBreaker(product.getCategoryId());
        product.setCategoryId(category.getId());
        product.setCategoryName(category.getName());

        return productRepository.save(product);
    }

    public Product updateProduct(Long id, Product productDetails) {
        ensureAdminRole();

        if (productDetails.getQuantity() < 0) {
            throw new IllegalArgumentException("Product quantity cannot be negative.");
        }

        return productRepository.findById(id)
                .map(product -> {
                    Category category = getCategoryWithCircuitBreaker(productDetails.getCategoryId());
                    product.setCategoryId(category.getId());
                    product.setCategoryName(category.getName());

                    product.setName(productDetails.getName());
                    product.setDescription(productDetails.getDescription());
                    product.setPrice(productDetails.getPrice());
                    product.setQuantity(productDetails.getQuantity());

                    return productRepository.save(product);
                })
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + id));
    }

    public boolean deleteProduct(Long id) {
        ensureAdminRole();

        return productRepository.findById(id)
                .map(product -> {
                    productRepository.deleteById(id);
                    return true;
                })
                .orElse(false);
    }

    @Transactional
    public boolean reduceProductQuantity(Long productId, int quantityToReduce) {
        if (quantityToReduce <= 0) {
            throw new IllegalArgumentException("Quantity to reduce must be greater than zero.");
        }

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));

        if (product.getQuantity() < quantityToReduce) {
            throw new IllegalArgumentException("Insufficient stock for product: " + product.getName());
        }

        product.setQuantity(product.getQuantity() - quantityToReduce);
        productRepository.save(product);
        return true;
    }

    @Transactional
    public void restoreProductQuantity(Long productId, int quantityToRestore) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));

        product.setQuantity(product.getQuantity() + quantityToRestore);
        productRepository.save(product);
    }

    private void attachCategoryName(Product product) {
        try {
            Category category = getCategoryWithCircuitBreaker(product.getCategoryId());
            product.setCategoryName(category.getName());
        } catch (Exception ex) {
            product.setCategoryName("Unavailable");
        }
    }

    private void ensureAdminRole() {
        if (!"ADMIN".equals(UserContext.getRole())) {
            throw new AccessDeniedException("Access denied: Only ADMIN users can perform this operation.");
        }
    }

    @CircuitBreaker(name = CATEGORY_CB, fallbackMethod = "fallbackCategory")
    public Category getCategoryWithCircuitBreaker(Long categoryId) {
        return categoryClient.getCategoryById(categoryId);
    }

    public Category fallbackCategory(Long categoryId, Throwable t) {
        return new Category(-1L, "", "Category service is down");
    }

    public String getCircuitBreakerState() {
        return circuitBreakerRegistry.circuitBreaker(CATEGORY_CB).getState().toString();
    }
}