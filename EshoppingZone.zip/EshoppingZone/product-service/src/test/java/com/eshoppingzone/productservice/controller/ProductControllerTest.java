package com.eshoppingzone.productservice.controller;

import com.eshoppingzone.productservice.entity.Product;
import com.eshoppingzone.productservice.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProductControllerTest {

    @Mock
    private ProductService productService;

    @InjectMocks
    private ProductController productController;

    private Product product1;
    private Product product2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        product1 = new Product();
        product1.setId(1L);
        product1.setName("Phone");

        product2 = new Product();
        product2.setId(2L);
        product2.setName("Laptop");
    }

    @Test
    void testGetAllProducts() {
        List<Product> productList = Arrays.asList(product1, product2);
        when(productService.getAllProducts()).thenReturn(productList);

        List<Product> result = productController.getAllProducts();

        assertEquals(2, result.size());
        verify(productService, times(1)).getAllProducts();
    }

    @Test
    void testGetProductByIdFound() {
        when(productService.getProductById(1L)).thenReturn(Optional.of(product1));

        ResponseEntity<Product> response = productController.getProductById(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(product1, response.getBody());
    }

    @Test
    void testGetProductByIdNotFound() {
        when(productService.getProductById(1L)).thenReturn(Optional.empty());

        ResponseEntity<Product> response = productController.getProductById(1L);

        assertEquals(404, response.getStatusCodeValue());
        assertNull(response.getBody());
    }

    @Test
    void testGetProductsByCategory() {
        when(productService.getProductsByCategory(1L)).thenReturn(List.of(product1));

        List<Product> result = productController.getProductsByCategory(1L);

        assertEquals(1, result.size());
        verify(productService).getProductsByCategory(1L);
    }

    @Test
    void testAddProductSuccess() {
        when(productService.addProduct(product1)).thenReturn(product1);

        ResponseEntity<?> response = productController.addProduct(product1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(product1, response.getBody());
    }

    @Test
    void testAddProductFailure() {
        when(productService.addProduct(product1)).thenThrow(new RuntimeException("Save failed"));

        ResponseEntity<?> response = productController.addProduct(product1);

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Save failed", response.getBody());
    }

    @Test
    void testUpdateProductSuccess() {
        when(productService.updateProduct(1L, product1)).thenReturn(product1);

        ResponseEntity<?> response = productController.updateProduct(1L, product1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(product1, response.getBody());
    }

    @Test
    void testUpdateProductNotFound() {
        when(productService.updateProduct(1L, product1)).thenReturn(null);

        ResponseEntity<?> response = productController.updateProduct(1L, product1);

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testUpdateProductFailure() {
        when(productService.updateProduct(1L, product1)).thenThrow(new RuntimeException("Update failed"));

        ResponseEntity<?> response = productController.updateProduct(1L, product1);

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Update failed", response.getBody());
    }

    @Test
    void testDeleteProductSuccess() {
        when(productService.deleteProduct(1L)).thenReturn(true);

        ResponseEntity<Void> response = productController.deleteProduct(1L);

        assertEquals(204, response.getStatusCodeValue());
    }

    @Test
    void testDeleteProductNotFound() {
        when(productService.deleteProduct(1L)).thenReturn(false);

        ResponseEntity<Void> response = productController.deleteProduct(1L);

        assertEquals(404, response.getStatusCodeValue());
    }
}
