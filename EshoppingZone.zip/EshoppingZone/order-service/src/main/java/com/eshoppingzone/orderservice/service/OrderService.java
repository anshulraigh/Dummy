package com.eshoppingzone.orderservice.service;

import com.eshoppingzone.orderservice.client.MessageClient;
import com.eshoppingzone.orderservice.client.PaymentClient;
import com.eshoppingzone.orderservice.client.ProductClient;
import com.eshoppingzone.orderservice.config.UserContext;
import com.eshoppingzone.orderservice.dto.MessageDto;
import com.eshoppingzone.orderservice.dto.PaymentRequest;
import com.eshoppingzone.orderservice.dto.PaymentResponse;
import com.eshoppingzone.orderservice.dto.Product;
import com.eshoppingzone.orderservice.exception.OrderNotFoundException;
import com.eshoppingzone.orderservice.exception.PaymentFailedException;
import com.eshoppingzone.orderservice.exception.ProductUnavailableException;
import com.eshoppingzone.orderservice.exception.UnauthorizedAccessException;
import com.eshoppingzone.orderservice.model.Order;
import com.eshoppingzone.orderservice.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class OrderService {

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    ProductClient productClient;

    @Autowired
    PaymentClient paymentClient;

    @Autowired
    MessageClient messageClient;

    @Transactional
    public PaymentResponse placeOrder(Order order) {
        Long userId = UserContext.getUserId();
        String email = UserContext.getEmail();
        String fullName = UserContext.getName();

        if (userId == null || userId <= 0) {
            throw new IllegalArgumentException("Invalid user ID.");
        }

        // Step 1: Validate product availability
        Product product = productClient.getProductById(order.getProductId());
        if (product == null || product.getQuantity() < order.getQuantity()) {
            throw new ProductUnavailableException("Product not available or insufficient stock.");
        }

        try {
            // Step 2: Reduce product quantity
            productClient.reduceProductQuantity(product.getId(), order.getQuantity());

            // Step 3: Create and save order
            order.setUserId(userId);
            order.setProductName(product.getName());
            order.setPrice(product.getPrice());
            order.setOrderDate(LocalDateTime.now());
            order.setStatus("PENDING");
            Order savedOrder = orderRepository.save(order);

            // Step 4: Prepare and make payment request
            PaymentRequest paymentRequest = new PaymentRequest(
                    savedOrder.getId(),
                    userId,
                    product.getPrice() * order.getQuantity(),
                    "card"
            );

            PaymentResponse paymentResponse = paymentClient.makePayment(paymentRequest);
            if (paymentResponse == null || paymentResponse.getSessionId() == null) {
                throw new PaymentFailedException("Payment gateway failed to return a valid response.");
            }

            // Step 5: Update order with sessionId & status
            savedOrder.setPaymentLink(paymentResponse.getPaymentLink());
            savedOrder.setStatus(paymentResponse.getStatus());
            savedOrder.setSessionId(paymentResponse.getSessionId());
            orderRepository.save(savedOrder);

            // Step 6: Send Order Confirmation Email
            String formattedDate = savedOrder.getOrderDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a"));
            String message = String.format(
                    "Dear %s,\n\n" +
                            "We’re thrilled to let you know that your order has been received and is now being processed.\n\n" +
                            "Order Summary:\n" +
                            "  • Order ID     : %s\n" +
                            "  • Order Date   : %s\n" +
                            "  • Product Name : %s\n" +
                            "  • Quantity     : %d\n" +
                            "  • Total Amount : ₹%.2f\n" +
                            "  • Payment Status: %s\n\n" +
                            "You’ll receive another notification once your package is out for delivery.\n\n" +
                            "Thank you for shopping with us.\n" +
                            "Warm regards,\n" +
                            "ShopEase Team",
                    fullName,
                    savedOrder.getId(),
                    formattedDate,
                    product.getName(),
                    order.getQuantity(),
                    savedOrder.getPrice() * savedOrder.getQuantity(),
                    "PAID".equalsIgnoreCase(paymentResponse.getStatus()) ? "Paid" : "Unpaid"
            );

            messageClient.sendMessage(new MessageDto(fullName, email, message));

            return paymentResponse;

        } catch (Exception ex) {
            log.error("Order placement failed: {}", ex.getMessage(), ex);
            productClient.restoreProductQuantity(order.getProductId(), order.getQuantity());
            throw new PaymentFailedException("Order placement failed: " + ex.getMessage());
        }
    }

    public ResponseEntity<String> sendOrderConfirmation(Long orderId) {
        Long userId = UserContext.getUserId();
        String email = UserContext.getEmail();
        String fullName = UserContext.getName();

        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isEmpty()) {
            throw new OrderNotFoundException("Order not found for confirmation.");
        }

        Order order = optionalOrder.get();
        if (!order.getUserId().equals(userId)) {
            throw new UnauthorizedAccessException("Access denied to send confirmation for this order.");
        }

        PaymentResponse paymentDetails = paymentClient.getPaymentStatus(order.getSessionId());
        if (paymentDetails == null) {
            throw new PaymentFailedException("Failed to retrieve payment details.");
        }

        order.setStatus(paymentDetails.getStatus());
        orderRepository.save(order);

        String message = String.format(
                "Dear %s,\n\n" +
                        "Here is an update on your order:\n\n" +
                        "Order ID     : %s\n" +
                        "Product      : %s\n" +
                        "Status       : %s\n\n" +
                        "Thank you for choosing us.\n\n" +
                        "Warm regards,\n" +
                        "ShopEase Team",
                fullName,
                order.getId(),
                order.getProductName(),
                paymentDetails.getStatus()
        );

        return messageClient.sendMessage(new MessageDto(fullName, email, message));
    }

    public List<Order> getOrders() {
        Long userId = UserContext.getUserId();
        String role = UserContext.getRole();

        if (isAdmin(role)) {
            return orderRepository.findAll();
        }
        return orderRepository.findByUserId(userId);
    }

    public Optional<Order> getOrderById(Long orderId) {
        Long userId = UserContext.getUserId();
        String role = UserContext.getRole();

        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isEmpty()) {
            throw new OrderNotFoundException("Order not found with ID: " + orderId);
        }

        Order order = orderOpt.get();
        if (!isAdmin(role) && !order.getUserId().equals(userId)) {
            throw new UnauthorizedAccessException("Access denied to this order.");
        }

        return orderOpt;
    }

    public Order updateOrderStatus(Long id, String status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + id));
        order.setStatus(status);
        return orderRepository.save(order);
    }

    public void cancelOrder(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + id));
        productClient.restoreProductQuantity(order.getProductId(), order.getQuantity());
        orderRepository.delete(order);
    }

    private boolean isAdmin(String role) {
        return "ADMIN".equalsIgnoreCase(role);
    }
}
