package com.eshoppingzone.orderservice.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.security.Key;

@Component
public class UserContextFilter extends OncePerRequestFilter {

    private static final String SECRET = "1234567812345678123456781234567812345678123456781234567812345678";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            try {
                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(getSignKey())
                        .build()
                        .parseClaimsJws(token)
                        .getBody();

                Long userId = claims.get("userId", Integer.class).longValue(); // Assuming ID is stored as Integer
                String role = claims.get("role", String.class);
                String name = claims.get("name", String.class);
                String email = claims.getSubject(); // or claims.get("email", String.class) if added in claims

                UserContext.setUserId(userId);
                UserContext.setRole(role);
                UserContext.setEmail(email);
                UserContext.setName(name);

            } catch (Exception e) {
                // Optionally log or handle token verification errors
            }
        }

        try {
            filterChain.doFilter(request, response);
        } finally {
            UserContext.clear(); // Clean up after request ends
        }
    }

    private Key getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
