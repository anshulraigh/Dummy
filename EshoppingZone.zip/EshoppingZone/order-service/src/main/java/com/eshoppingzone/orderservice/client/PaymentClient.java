package com.eshoppingzone.orderservice.client;

import com.eshoppingzone.orderservice.dto.PaymentRequest;
import com.eshoppingzone.orderservice.dto.PaymentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "payment-service", fallback = PaymentClientFallback.class)
public interface PaymentClient {

    @PostMapping("/checkout/payment")
    PaymentResponse makePayment(@RequestBody PaymentRequest paymentRequest);

    @GetMapping("/api/paymentStatus")
    PaymentResponse getPaymentStatus(@RequestParam("session_id") String sessionId);

    @GetMapping("/api/paymentStatus")
    PaymentResponse verifyPayment(@RequestParam("session_id") String sessionId);
}