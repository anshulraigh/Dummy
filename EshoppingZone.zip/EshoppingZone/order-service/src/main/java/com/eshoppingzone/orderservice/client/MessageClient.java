package com.eshoppingzone.orderservice.client;
import com.eshoppingzone.orderservice.dto.MessageDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "message-service")
public interface MessageClient {
    @PostMapping("/message/publish")
    ResponseEntity<String> sendMessage(@RequestBody MessageDto messageDto);
}
