package com.eshoppingzone.paymentgateway.controller;

import com.eshoppingzone.paymentgateway.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class PaymentStatus {

    @Autowired
    StripeService stripeService;

    @GetMapping("/paymentStatus")
    public ResponseEntity<String> checkPaymentStatus(@RequestParam("session_id") String sessionId) {
        return stripeService.getPaymentStatus(sessionId);
    }
}
